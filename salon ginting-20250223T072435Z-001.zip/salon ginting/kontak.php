<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ginting Salon - Contact</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="script.js"></script>
</head>
<body>

<!-- Navbar -->
<?php include 'navbar.php'; ?>

<!-- Container Contact -->
<div class="container mt-5">
    <div class="row">
        <!-- Form Contact -->
        <div class="col-md-8">
            <div class="card shadow p-4">
                <h2 class="text-center text-muted"><span class="glyphicon glyphicon-list"></span> Contact</h2>
                <form>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" class="form-control" placeholder="Isikan nama Anda" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Alamat Email</label>
                        <input type="email" name="email" class="form-control" placeholder="Isikan email aktif" required>
                    </div>

                    <div class="form-group">
                        <label for="pesan">Pesan</label>
                        <textarea name="pesan" class="form-control" rows="4" placeholder="Tulis pesan Anda" required></textarea>
                    </div>

                    <button type="submit" class="btn btn-info btn-lg">Konfirmasi</button>
                    <button type="reset" class="btn btn-warning btn-lg">Cancel</button>
                </form>
            </div>
        </div>

        <!-- Foto dan Info -->
        <div class="col-md-4">
            <div class="card shadow p-4 text-center">
                <h2>Ginting Salon</h2>
                <img src="foto/c1.jpeg" class="img-fluid img-thumbnail" alt="Salon Image">
                <p class="mt-3"><b>Saran dan kritik Anda sangat berguna bagi kami.</b></p>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="footer mt-5">
    <div class="container text-center">
        <p>&copy; Ginting Salon | Jl. Sisingamangaraja No.13</p>
        <p>Jl. Kapten Muslim No.20 | Jl. Jamin Ginting No.45</p>
    </div>
</footer>

</body>
</html>
