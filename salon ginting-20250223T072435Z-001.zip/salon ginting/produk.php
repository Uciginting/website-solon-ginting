<?php
include 'koneksi.php';
include 'navbar.php';

$query = "SELECT * FROM produk";
$result = mysqli_query($conn, $query);
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">Layanan Salon</h2>
    <div class="row">
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                <img src="<?= !empty($row['gambar']) ? 'img/' . $row['gambar'] : 'img/default.jpg'; ?>" 
                class="card-img-top" alt="<?= $row['nama_produk']; ?>">
                    <div class="card-body text-center">
                        <h5 class="card-title"><?= $row['nama_produk']; ?></h5>
                        <p class="card-text"><?= $row['deskripsi']; ?></p>
                        <p class="card-text"><strong>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></strong></p>
                        <button class="btn btn-primary pesan-btn" data-toggle="modal" data-target="#pesanModal">Pesan</button>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="pesanModal" tabindex="-1" role="dialog" aria-labelledby="pesanModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="pesanModalLabel">Pesanan Berhasil</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">
                <p>Terima kasih telah memesan layanan kami!</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<!-- Tambahkan Bootstrap & jQuery -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
