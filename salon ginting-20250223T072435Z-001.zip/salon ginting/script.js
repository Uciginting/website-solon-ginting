$(document).ready(function () {
    // Menutup modal setelah beberapa detik
    $('#pesanModal').on('shown.bs.modal', function () {
        setTimeout(function () {
            $('#pesanModal').modal('hide');
        }, 3000); // Modal otomatis tertutup dalam 3 detik
    });

    // Efek tombol saat diklik
    $('.pesan-btn').on('click', function () {
        $(this).text("Diproses...").attr("disabled", true);
        setTimeout(() => {
            $(this).text("Pesan").attr("disabled", false);
        }, 2000);
    });
});
