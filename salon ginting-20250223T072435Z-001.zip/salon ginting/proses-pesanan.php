<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $produk = $_POST['produk'];
    $harga = $_POST['harga'];
    $nama = $_POST['nama'];
    $nomor_hp = $_POST['nomor_hp'];
    $alamat = $_POST['alamat'];

    $query = "INSERT INTO pesanan (produk, harga, nama, nomor_hp, alamat) VALUES ('$produk', '$harga', '$nama', '$nomor_hp', '$alamat')";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Pesanan berhasil dibuat!'); window.location='produk.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan!'); window.location='produk.php';</script>";
    }
}
?>
