<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ginting Salon</title>
    <!-- Bootstrap 5 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .carousel-item img {
            height: 500px;
            object-fit: cover;
        }
        .carousel-caption {
            background: rgba(0, 0, 0, 0.5);
            padding: 10px;
            border-radius: 5px;
        }
        .card img {
            height: 200px;
            object-fit: cover;
        }
        .footer {
            background-color: #6d4c41;
            color: white;
            padding: 15px;
            text-align: center;
            margin-top: 50px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<?php include 'navbar.php'; ?>

<!-- Carousel -->
<div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="0" class="active"></button>
        <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="2"></button>
    </div>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="foto/d1.jpeg" class="d-block w-100" alt="Salon Ginting 1">
            <div class="carousel-caption d-none d-md-block">
                <h3>Ginting Salon</h3>
                <p>Perawatan terbaik untuk kecantikan Anda.</p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="foto/d2.jpeg" class="d-block w-100" alt="Salon Ginting 2">
            <div class="carousel-caption d-none d-md-block">
                <h3>Salon Nyaman & Modern</h3>
                <p>Rasakan pengalaman terbaik.</p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="foto/d3.jpeg" class="d-block w-100" alt="Salon Ginting 3">
            <div class="carousel-caption d-none d-md-block">
                <h3>Hasil Maksimal</h3>
                <p>Kami hadir untuk kecantikan Anda.</p>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>
</div>

<!-- Tentang Ginting Salon -->
<div class="container text-center my-5">
    <h2 class="text-uppercase fw-bold">Ginting Salon</h2>
    <p>Ginting Salon berdiri pada 20 Juli 2023, didirikan oleh Uci Ginting dengan tujuan meningkatkan rasa percaya diri wanita melalui berbagai perawatan kecantikan. Ginting Salon kini memiliki beberapa cabang di berbagai kota, termasuk Medan.</p>
</div>

<!-- Cabang Ginting Salon -->
<div class="container">
    <h2 class="text-center text-uppercase fw-bold">Cabang Kami</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <img src="foto/c1.jpeg" class="card-img-top" alt="Cabang Medan">
                <div class="card-body text-center">
                    <h5>Cabang Medan</h5>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="foto/c2.jpeg" class="card-img-top" alt="Cabang Pekanbaru">
                <div class="card-body text-center">
                    <h5>Cabang Pekanbaru</h5>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="foto/c3.jpeg" class="card-img-top" alt="Cabang Tebing Tinggi">
                <div class="card-body text-center">
                    <h5>Cabang Tebing Tinggi</h5>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Layanan Kecantikan -->
<div class="container text-center my-5">
    <h2 class="text-uppercase fw-bold" >Layanan Perawatan</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <img src="foto/a1.jpeg" class="card-img-top" alt="Face Treatment">
                <div class="card-body">
                    <h5 class="card-title" id="face">Face Treatment</h5>
                    <p class="card-text">Perawatan wajah terbaik untuk kulit Anda.</p>
                    <a href="produk.php" class="btn btn-primary">Lihat Selengkapnya</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="foto/a2.jpeg" class="card-img-top" alt="Body Treatment">
                <div class="card-body">
                    <h5 class="card-title" id="body">Body Treatment</h5>
                    <p class="card-text">Perawatan tubuh yang menyegarkan.</p>
                    <a href="produk.php" class="btn btn-primary">Lihat Selengkapnya</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="foto/a3.jpeg" class="card-img-top" alt="Nail Art">
                <div class="card-body">
                    <h5 class="card-title" id="nail">Nail Art</h5>
                    <p class="card-text">Desain kuku yang cantik dan modern.</p>
                    <a href="produk.php" class="btn btn-primary">Lihat Selengkapnya</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    <p>Copyright &copy; 2025 Ginting Salon</p>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
