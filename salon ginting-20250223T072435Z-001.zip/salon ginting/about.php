<?php include 'navbar.php'; ?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tentang Kami | Ginting Salon</title>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="bootstrap/js/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="script.js"></script>

    <style>
        body {
            padding-top: 70px;
        }
        .about-text {
            text-align: justify;
        }
        .gallery img {
            width: 100%;
            height: auto;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center text-muted">
        <span class="glyphicon glyphicon-list"></span> Tentang Ginting Salon
    </h2>
    <hr>

    <!-- Galeri Gambar -->
    <div class="row gallery">
        <div class="col-md-4">
            <img src="foto/b3.jpeg" class="img-thumbnail img-responsive" alt="Salon Interior">
        </div>
        <div class="col-md-4">
            <img src="foto/b2.jpeg" class="img-thumbnail img-responsive" alt="Perawatan Rambut">
        </div>
        <div class="col-md-4">
            <img src="foto/c1.jpeg" class="img-thumbnail img-responsive" alt="Pelanggan di Salon">
        </div>
    </div>

    <!-- Deskripsi -->
    <div class="about-text">
        <p>
            <strong>Ginting Salon</strong> berdiri pada <strong>20 Juli 2023</strong>. Salon ini didirikan oleh <strong>Uci Ginting</strong>, 
            yang memiliki impian untuk membantu para wanita tampil lebih percaya diri melalui perawatan kecantikan berkualitas.
            Saat ini, Ginting Salon telah memiliki beberapa cabang di berbagai kota, termasuk di Medan.
        </p>

        <h3>Jenis Perawatan di Ginting Salon</h3>
        <p>Ginting Salon menyediakan berbagai layanan perawatan kecantikan, antara lain:</p>
        <ul>
            <li>💆 Face Treatment</li>
            <li>🧖 Body Treatment</li>
            <li>✂️ Hair Salon Treatment</li>
            <li>💅 Nail Art</li>
            <li>🎀 Brow Bomber</li>
            <li>👁️ Eyelash Extension</li>
            <li>✨ Radio Frequency</li>
        </ul>
    </div>

    <hr>

    <!-- CTA ke Halaman Produk -->
    <div class="text-center">
        <h3>Ginting Salon Menyediakan Semua Jenis Treatment!</h3>
        <a class="btn btn-warning btn-lg" href="produk.php" role="button">Lihat Layanan Kami</a>
    </div>
</div>

<!-- Footer -->
<footer class="text-center" style="margin-top: 50px;">
    <p>Copyright <span class="glyphicon glyphicon-copyright-mark"></span> 2025 Ginting Salon. All Rights Reserved.</p>
</footer>

<script src="bootstrap/js/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
