<?php
include 'koneksi.php';
include 'navbar.php';

$query = "SELECT * FROM pelanggan";
$result = mysqli_query($conn, $query);
?>

<div class="container mt-4">
    <h2>Data Pelanggan</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>No HP</th>
                <th>Alamat</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['nama']; ?></td>
                    <td><?= $row['no_hp']; ?></td>
                    <td><?= $row['alamat']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
